// Rota GET para /register
app.get('/register', (req, res) => {
    res.send('Por favor, use o método POST para registrar um usuário.');
});
